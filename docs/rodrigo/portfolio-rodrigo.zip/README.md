# Portfólio de Rodrigo Carneiro

O site usa HTML e CSS. Não exige instalação, JavaScript ou compilação.

## Arquivos

```text
index.html
styles.css
.nojekyll
assets/
  rodrigo.jpg
  porto.png
  favicon.svg
docs/
  curriculo-rodrigo-2026.pdf
  curriculo.md
  README.md
README.md
```

## Ver antes de publicar

Extraia o ZIP. Abra `index.html` no navegador.
Mantenha os arquivos e pastas juntos. Os recursos usam caminhos relativos.

## Publicar no GitHub Pages

Crie um repositório chamado `portfolio-rodrigo` no GitHub.
Use um repositório novo para preservar o portfólio de Nicolas.
Escolha a visibilidade pública se sua conta não oferece Pages para repositórios privados.

1. Abra o repositório.
2. Selecione **Add file → Upload files**.
3. Envie o conteúdo extraído do ZIP para a raiz da branch `main`.
4. Confira se `index.html`, `styles.css`, `assets/` e `docs/` aparecem na raiz.
5. Salve com **Commit changes**.
6. Abra **Settings → Pages**.
7. Em **Build and deployment**, selecione **Deploy from a branch**.
8. Selecione **main** e **/(root)**.
9. Selecione **Save**.
10. Aguarde a implantação. Use o endereço exibido na tela Pages.

Não envie somente o ZIP. O GitHub Pages precisa dos arquivos extraídos.
Não é necessário um workflow personalizado para esse método.

O currículo contém dados pessoais. Ao usar um repositório público, o PDF também ficará acessível.
O botão de download entrega o PDF original, sem a experiência acrescentada depois.
A experiência de PMO consta na página e no documento `docs/curriculo.md`.

## Conteúdo

A foto foi extraída do currículo recebido.
O fundo decorativo do Porto foi gerado por IA para esta apresentação.
O intercâmbio no IPMAIA foi confirmado pelo usuário como 2026–2027.
O currículo original foi preservado sem alterações.
A experiência de PMO usa a empresa, o cargo e as datas fornecidos pelo usuário.
As funções descritas são atividades típicas de PMO solicitadas pelo usuário.
Nenhum resultado, métrica ou ferramenta específica foi inventado.
A página não apresenta os dados ou projetos pessoais de Nicolas.
Marketing digital não foi acrescentado como experiência sem confirmação específica.

## Verificações

A página foi inspecionada no Chromium em computador e celular.
Não houve rolagem horizontal nas larguras 320, 390, 768, 1024 e 1536 pixels.
As âncoras e os recursos locais foram verificados.
A integridade da cópia do PDF foi conferida.
Essas verificações não representam uma certificação de acessibilidade.

## Projetos publicados

- [OptiGrow](https://optigrow.vercel.app/).
- [Ferradura](https://ferradura-phi.vercel.app/).
- [Serena](https://serena-five-fawn.vercel.app/).
- [SGCS](https://sgcs-seven.vercel.app/).

Os links foram fornecidos pelo usuário. Nenhuma função específica nesses projetos foi inferida.
